from sklearn.metrics import confusion_matrix, accuracy_score
import numpy as np

class EvaluatorAgent:
    """
    An agent that evaluates the performance of the detection and explanation agents.
    """

    def __init__(self):
        """
        Initializes the evaluator agent.
        """
        self.y_true = []
        self.y_pred = []
        self.explanation_rewards = []

    def evaluate_detection(self, detection_result, ground_truth):
        """
        Evaluates the detection result and returns a reward for the detection A/B agent.
        """
        prediction, _ = detection_result
        self.y_true.append(ground_truth)
        self.y_pred.append(prediction)

        if prediction == ground_truth:
            return 1.0  # Reward for correct prediction
        else:
            return 0.0  # No reward for incorrect prediction
    
    def evaluate_explanation(self, explanation_variant, golden_preference):
        """
        Evaluates the explanation against the 'golden set' preference and returns a reward.
        """
        reward = 1.0 if explanation_variant == golden_preference else 0.0
        self.explanation_rewards.append(reward)
        return reward

    def get_metrics(self):
        """
        Calculates and returns the performance metrics.
        """
        if not self.y_true:
            return {
                "accuracy": 0,
                "false_positives": 0,
                "trust_metric": 0,
                "total_transactions": 0,
            }

        tn, fp, fn, tp = confusion_matrix(self.y_true, self.y_pred, labels=[0, 1]).ravel()
        accuracy = accuracy_score(self.y_true, self.y_pred)
        
        # Calculate the trust metric as the running average of explanation rewards
        trust_metric = np.mean(self.explanation_rewards) if self.explanation_rewards else 0
        
        return {
            "accuracy": accuracy,
            "false_positives": fp,
            "true_positives": tp,
            "false_negatives": fn,
            "true_negatives": tn,
            "trust_metric": trust_metric,
            "total_transactions": len(self.y_true),
        }
