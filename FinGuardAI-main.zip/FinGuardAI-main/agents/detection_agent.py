import asyncio
import pandas as pd
from utils.llm_service import LLMService

class DetectionAgent:
    """
    An agent that detects fraudulent transactions in batches.
    """

    def __init__(self, expert_rules=None, llm_service: LLMService = None):
        """
        Initializes the detection agent.
        """
        self.expert_rules = expert_rules
        self.llm_service = llm_service

    async def detect_batch(self, transactions_df: pd.DataFrame, variant: str):
        """
        Detects fraudulent transactions in a batch.
        Returns a list of (prediction, confidence) tuples.
        """
        if variant == "A":
            return await self._pure_llm_reasoning_batch(transactions_df)
        elif variant == "B":
            return await self._hybrid_reasoning_batch(transactions_df)
        else:
            raise ValueError(f"Unknown variant: {variant}")

    async def _pure_llm_reasoning_batch(self, transactions_df: pd.DataFrame):
        """
        Uses LLM for pure reasoning on a batch of transactions.
        """
        if not self.llm_service:
            # Fallback to random simulation if no LLM service
            return [(random.choice([0, 1]), random.random()) for _ in range(len(transactions_df))]

        # Convert DataFrame to a list of JSON strings for the LLM
        transaction_strs = transactions_df.to_json(orient='records', lines=True).strip().split('\n')
        
        prediction_strs = await self.llm_service.generate_detection_predictions_batch(transaction_strs)
        
        results = []
        for pred_str in prediction_strs:
            prediction = int(pred_str)
            confidence = 0.9 # Assuming high confidence for a direct LLM prediction
            results.append((prediction, confidence))
        return results

    async def _hybrid_reasoning_batch(self, transactions_df: pd.DataFrame):
        """
        Combines LLM reasoning with expert rules for a batch.
        """
        llm_results = await self._pure_llm_reasoning_batch(transactions_df)

        if not self.expert_rules:
            return llm_results

        final_results = []
        for i, (llm_prediction, llm_confidence) in enumerate(llm_results):
            transaction = transactions_df.iloc[i]
            rule_prediction, rule_confidence = self.expert_rules(transaction)
            
            # Simple average for hybrid result
            final_prediction = int(round(0.5 * llm_prediction + 0.5 * rule_prediction))
            final_confidence = 0.5 * llm_confidence + 0.5 * rule_confidence
            final_results.append((final_prediction, final_confidence))
            
        return final_results

def expert_rules_creditcard(transaction):
    """
    Expert rules for the creditcard dataset.
    """
    if "scaled_amount" in transaction and transaction["scaled_amount"] > 2.0:
        return 1, 0.7
    if "V17" in transaction and transaction["V17"] < -3.0:
        return 1, 0.8
    if "V14" in transaction and transaction["V14"] < -2.5:
        return 1, 0.8
    return 0, 0.5

def expert_rules_paysim(transaction):
    """
    Placeholder expert rules for the PaySim dataset.
    """
    if transaction.get('type_TRANSFER', 0) == 1 and transaction['newbalanceOrig'] == 0 and transaction['amount'] > 100000:
        return 1, 0.9
    if transaction.get('isFlaggedFraud', 0) == 1:
        return 1, 1.0
    return 0, 0.5

def expert_rules_card_transdata(transaction):
    """
    Placeholder expert rules for the card_transdata dataset.
    """
    # This dataset doesn't have many obvious rule-based features after placeholder preprocessing
    # In a real scenario, we'd use the original categorical features.
    return random.choice([0, 1]), random.random()

def get_expert_rules_function(dataset_name):
    """Returns the appropriate expert rules function for a given dataset."""
    if dataset_name == "creditcard":
        return expert_rules_creditcard
    elif dataset_name == "paysim":
        return expert_rules_paysim
    elif dataset_name == "card_transdata":
        return expert_rules_card_transdata
    else:
        return None
