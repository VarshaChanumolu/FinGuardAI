import asyncio
import pandas as pd
from typing import List, Tuple
from utils.rag import get_rag_retriever
from utils.llm_service import LLMService

class ExplanationAgent:
    """
    An agent that generates explanations for flagged transactions in batches.
    """

    def __init__(self, rag_retriever=None, llm_service: LLMService = None, expert_rules_func=None):
        """
        Initializes the explanation agent.
        """
        self.rag_retriever = rag_retriever if rag_retriever else get_rag_retriever()
        self.llm_service = llm_service
        self.expert_rules_func = expert_rules_func

    def _numeric_breakdown(self, transaction, detection_result, selected_dataset_name):
        """
        Generates a numeric risk-factor breakdown for a single transaction.
        """
        _, confidence = detection_result
        explanation = "Risk Factor Breakdown:\n"
        
        if self.expert_rules_func:
            if selected_dataset_name == "creditcard":
                if "scaled_amount" in transaction and transaction["scaled_amount"] > 2.0:
                    explanation += f"- High transaction amount: {transaction['scaled_amount']:.2f} (Confidence: 0.7)\n"
                if "V17" in transaction and transaction["V17"] < -3.0:
                    explanation += f"- Suspicious V17 value: {transaction['V17']:.2f} (Confidence: 0.8)\n"
                if "V14" in transaction and transaction["V14"] < -2.5:
                    explanation += f"- Suspicious V14 value: {transaction['V14']:.2f} (Confidence: 0.8)\n"
            elif selected_dataset_name == "paysim":
                if transaction.get('type_TRANSFER', 0) == 1 and transaction['newbalanceOrig'] == 0 and transaction['amount'] > 100000:
                    explanation += f"- Large transfer draining account (Amount: {transaction['amount']:.2f})\n"
                if transaction.get('isFlaggedFraud', 0) == 1:
                    explanation += f"- Transaction flagged by system (isFlaggedFraud: 1)\n"
        
        explanation += f"\nOverall Confidence: {confidence:.2f}"
        return explanation

    async def explain_batch(self, transactions_df: pd.DataFrame, detection_results: List[Tuple[int, float]], variants: List[str], selected_dataset_name: str):
        """
        Generates a batch of explanations, handling numeric and narrative variants efficiently.
        """
        final_explanations = [""] * len(transactions_df)
        narrative_indices = []
        narrative_data_for_llm = []

        # First pass: identify transactions needing a narrative explanation
        for i, (detection_result, variant) in enumerate(zip(detection_results, variants)):
            if detection_result[0] == 1 and variant == "D":
                narrative_indices.append(i)
                transaction_str = transactions_df.iloc[i].to_json()
                query = f"Suspicious transaction data: {transaction_str}"
                retrieved_docs = self.rag_retriever.retrieve(query, k=1)
                rag_context = retrieved_docs[0] if retrieved_docs else "No relevant documents found."
                
                # Truncate RAG context to avoid exceeding token limits
                truncated_rag_context = rag_context[:2000]

                narrative_data_for_llm.append({
                    "transaction_str": transaction_str,
                    "rag_context": truncated_rag_context,
                    "detection_result_str": f"Fraudulent (Confidence: {detection_result[1]:.2f})"
                })

        # Batch call for all narrative explanations
        narrative_explanations_llm = []
        if narrative_data_for_llm and self.llm_service:
            narrative_explanations_llm = await self.llm_service.generate_narrative_explanations_batch(
                [d["transaction_str"] for d in narrative_data_for_llm],
                [d["rag_context"] for d in narrative_data_for_llm],
                [d["detection_result_str"] for d in narrative_data_for_llm]
            )

        # Create a map from original index to the narrative explanation
        narrative_map = dict(zip(narrative_indices, narrative_explanations_llm))

        # Second pass: construct the final list of explanations
        for i, (detection_result, variant) in enumerate(zip(detection_results, variants)):
            if detection_result[0] != 1:
                final_explanations[i] = "Not Flagged"
                continue

            if variant == "C":
                transaction = transactions_df.iloc[i]
                final_explanations[i] = self._numeric_breakdown(transaction, detection_result, selected_dataset_name)
            elif variant == "D":
                # Retrieve the pre-fetched explanation
                explanation = narrative_map.get(i)
                if explanation:
                    final_explanations[i] = explanation
                else:
                    # Fallback if LLM service failed for this specific item
                    final_explanations[i] = f"This transaction has been flagged as potentially fraudulent with a confidence of {detection_result[1]:.2f}. (LLM failed to generate narrative)"
        
        return final_explanations
