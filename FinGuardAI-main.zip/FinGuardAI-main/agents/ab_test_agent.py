import numpy as np

class ABTestAgent:
    """
    An agent that uses Thompson Sampling to choose between different variants.
    """

    def __init__(self, variants):
        """
        Initializes the A/B test agent.

        Args:
            variants (list): A list of variant names.
        """
        self.variants = variants
        self.successes = {variant: 0 for variant in variants}
        self.failures = {variant: 0 for variant in variants}

    def choose_variant(self):
        """
        Chooses a variant using Thompson Sampling.

        Returns:
            str: The name of the chosen variant.
        """
        samples = [np.random.beta(self.successes[v] + 1, self.failures[v] + 1) for v in self.variants]
        return self.variants[np.argmax(samples)]

    def update(self, variant, reward):
        """
        Updates the distribution for the selected variant based on the reward.

        Args:
            variant (str): The name of the variant that was used.
            reward (float): The reward received (e.g., 1 for success, 0 for failure).
        """
        if reward > 0:
            self.successes[variant] += 1
        else:
            self.failures[variant] += 1
