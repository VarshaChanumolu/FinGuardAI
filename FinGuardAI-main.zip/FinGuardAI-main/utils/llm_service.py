import os
import asyncio
from groq import AsyncGroq
from dotenv import load_dotenv
from typing import List

# Load environment variables from .env file
load_dotenv()

class LLMService:
    """
    Service for interacting with the Groq API asynchronously.
    """
    def __init__(self, model_id="llama-3.1-8b-instant"):
        """
        Initializes the async Groq client and a semaphore for rate limiting.
        """
        try:
            self.client = AsyncGroq(api_key=os.environ.get("GROQ_API_KEY"))
            self.model_id = model_id
            self.semaphore = asyncio.Semaphore(3) # Limit to 3 concurrent requests
        except Exception as e:
            raise RuntimeError(f"Failed to initialize Groq client: {e}. Please ensure GROQ_API_KEY is set in your .env file.")

    async def _query_groq(self, messages, max_new_tokens):
        """Helper function to query the Groq API asynchronously, respecting the semaphore."""
        async with self.semaphore:
            try:
                # Add a small delay to help with TPM limits
                await asyncio.sleep(0.1) 
                chat_completion = await self.client.chat.completions.create(
                    messages=messages,
                    model=self.model_id,
                    temperature=0.5,
                    max_tokens=max_new_tokens,
                    top_p=1,
                    stop=None,
                )
                return chat_completion.choices[0].message.content.strip()
            except Exception as e:
                print(f"--- GROQ API ERROR ---\n{e}\n--------------------")
                return "" # Return empty string on failure

    async def generate_detection_predictions_batch(self, transactions_data: List[str]) -> List[str]:
        """
        Generates a batch of fraud detection predictions using the Groq API.
        """
        tasks = []
        for trans_data in transactions_data:
            messages = [
                {"role": "system", "content": "You are a highly specialized fraud detection model. Your only task is to classify a transaction. Respond with only the digit '1' for fraudulent or '0' for not fraudulent. Do not provide any other text, symbols, or explanation."},
                {"role": "user", "content": f"Classify the following transaction data: {trans_data}"},
            ]
            tasks.append(self._query_groq(messages, max_new_tokens=2))
        
        results = await asyncio.gather(*tasks)
        
        # Post-process results to ensure correct format
        final_predictions = []
        for text in results:
            found = False
            for char in text:
                if char in ['0', '1']:
                    final_predictions.append(char)
                    found = True
                    break
            if not found:
                final_predictions.append("0") # Fallback if no digit is found or if API failed
        return final_predictions
    
    async def generate_narrative_explanations_batch(self, transactions_data: List[str], rag_contexts: List[str], detection_results: List[str]) -> List[str]:
        """
        Generates a batch of narrative explanations using the Groq API.
        """
        tasks = []
        for i in range(len(transactions_data)):
            messages = [
                {"role": "system", "content": "You are a senior financial fraud analyst. Your task is to write a brief, clear narrative explaining a fraud detection result for another analyst to review. Use the provided data and context. Keep your explanation concise and under 100 characters."},
                {"role": "user", "content": (
                    "Please generate an explanation for the following case:\n"
                    f"## Transaction Data:\n{transactions_data[i]}\n\n"
                    f"## Detection Result:\n{detection_results[i]}\n\n"
                    f"## Context from Knowledge Base:\n{rag_contexts[i]}"
                )},
            ]
            tasks.append(self._query_groq(messages, max_new_tokens=50)) # Reduced max_tokens as well
        
        return await asyncio.gather(*tasks)
