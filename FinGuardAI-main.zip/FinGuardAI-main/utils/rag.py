from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from .data_loader import load_narrative_data

class RAG:
    """
    A simple RAG system for retrieving relevant documents.
    """

    def __init__(self, model_name="all-MiniLM-L6-v2"):
        """
        Initializes the RAG system.

        Args:
            model_name (str): The name of the sentence transformer model to use.
        """
        self.model = SentenceTransformer(model_name)
        self.index = None
        self.documents = []

    def build_index(self, narrative_data):
        """
        Builds the FAISS index from the narrative data.

        Args:
            narrative_data (dict): A dictionary of narrative documents.
        """
        self.documents = list(narrative_data.values())
        embeddings = self.model.encode(self.documents, convert_to_tensor=True)
        embeddings = embeddings.cpu().numpy()
        self.index = faiss.IndexFlatL2(embeddings.shape[1])
        self.index.add(embeddings)

    def retrieve(self, query, k=1):
        """
        Retrieves the most relevant documents for a given query.

        Args:
            query (str): The query to search for.
            k (int): The number of documents to retrieve.

        Returns:
            list: A list of the most relevant documents.
        """
        if self.index is None:
            raise Exception("Index has not been built yet. Call build_index() first.")

        query_embedding = self.model.encode([query], convert_to_tensor=True)
        query_embedding = query_embedding.cpu().numpy()
        distances, indices = self.index.search(query_embedding, k)
        return [self.documents[i] for i in indices[0]]

def get_rag_retriever():
    """
    Initializes and returns a RAG retriever.
    """
    narrative_data = load_narrative_data()
    rag = RAG()
    rag.build_index(narrative_data)
    return rag
