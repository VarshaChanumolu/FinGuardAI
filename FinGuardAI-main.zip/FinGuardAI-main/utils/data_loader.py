import pandas as pd
import os
import numpy as np
from pypdf import PdfReader
from sklearn.preprocessing import StandardScaler, OneHotEncoder

def load_transactional_data(data_dir="data"):
    """
    Loads all transactional data from CSV files in the specified directory.
    """
    data = {}
    for filename in os.listdir(data_dir):
        if filename.endswith(".csv"):
            file_path = os.path.join(data_dir, filename)
            df = pd.read_csv(file_path)
            # A bit of cleaning for memory saving
            if 'paysim' in filename:
                df = df.rename(columns={'oldbalanceOrg':'oldbalanceOrig', 'newbalanceOrig':'newbalanceOrig', 'oldbalanceDest':'oldbalanceDest', 'newbalanceDest':'newbalanceDest'})
                df = df.astype({'type': 'category', 'isFraud': 'uint8', 'isFlaggedFraud': 'uint8'})
            data[os.path.splitext(filename)[0]] = df
    return data

def load_narrative_data(data_dir="rag"):
    """
    Loads all narrative data from PDF files in the specified directory.
    """
    data = {}
    for filename in os.listdir(data_dir):
        if filename.endswith(".pdf"):
            file_path = os.path.join(data_dir, filename)
            text = ""
            with open(file_path, "rb") as f:
                reader = PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text()
            data[os.path.splitext(filename)[0]] = text
    return data

def preprocess_creditcard_data(df):
    """
    Preprocesses the creditcard dataset.
    """
    df['scaled_amount'] = StandardScaler().fit_transform(df['Amount'].values.reshape(-1, 1))
    df['scaled_time'] = StandardScaler().fit_transform(df['Time'].values.reshape(-1, 1))
    df.drop(['Time', 'Amount'], axis=1, inplace=True)
    
    # Simulate a "golden set" of analyst preferences for explanation style
    np.random.seed(42) # for reproducibility
    df['golden_explanation_preference'] = np.random.choice(['C', 'D'], size=len(df), p=[0.5, 0.5])
    
    return df

def preprocess_paysim_data(df):
    """
    Placeholder preprocessing for the paysim dataset.
    """
    # Simple one-hot encoding for the 'type' column
    encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    encoded_type = encoder.fit_transform(df[['type']])
    encoded_df = pd.DataFrame(encoded_type, columns=encoder.get_feature_names_out(['type']))
    
    df = df.join(encoded_df)
    df.drop(['type', 'nameOrig', 'nameDest'], axis=1, inplace=True)

    # Scale numerical columns
    for col in ['amount', 'oldbalanceOrig', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']:
         df[col] = StandardScaler().fit_transform(df[col].values.reshape(-1, 1))

    df = df.fillna(0)

    # Simulate a "golden set" with a 7:3 preference for Variant D
    np.random.seed(42) # for reproducibility
    df['golden_explanation_preference'] = np.random.choice(['C', 'D'], size=len(df), p=[0.7, 0.3])
    
    return df


def preprocess_card_transdata_data(df):
    """
    Placeholder preprocessing for the card_transdata dataset.
    """
    # This dataset has many categorical features that would need encoding
    # For now, we'll just scale the numerical ones and drop the categoricals
    df.drop(['distance_from_home', 'distance_from_last_transaction', 'ratio_to_median_purchase_price', 'repeat_retailer', 'used_chip', 'used_pin_number', 'online_order'], axis=1, inplace=True)
    df = df.rename(columns={'fraud': 'Class'})
    return df.fillna(0)


def get_preprocessing_function(dataset_name):
    """Returns the appropriate preprocessing function for a given dataset."""
    if dataset_name == "creditcard":
        return preprocess_creditcard_data
    elif dataset_name == "paysim":
        return preprocess_paysim_data
    elif dataset_name == "card_transdata":
        return preprocess_card_transdata_data
    else:
        # Default fallback that does nothing
        return lambda df: df

def get_target_column(dataset_name):
    """Returns the name of the target column for a given dataset."""
    if dataset_name == "paysim":
        return "isFraud"
    elif dataset_name == "card_transdata":
        return "Class" # Renamed in preprocessing
    else: # creditcard
        return "Class"
